package pl.edu.pjatk.jaz.jazs23575nbp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JazS23575NbpApplication {

	public static void main(String[] args) {
		SpringApplication.run(JazS23575NbpApplication.class, args);
	}

}
