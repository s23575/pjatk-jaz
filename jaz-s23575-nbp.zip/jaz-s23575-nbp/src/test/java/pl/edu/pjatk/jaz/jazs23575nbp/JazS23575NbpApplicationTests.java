package pl.edu.pjatk.jaz.jazs23575nbp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JazS23575NbpApplicationTests {

	@Test
	void contextLoads() {
	}

}
